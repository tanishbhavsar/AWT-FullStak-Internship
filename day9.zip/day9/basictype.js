

// the to exponential method returns a string with number 

let numexp = 3.14;
document.write("<br/>"+numexp.toExponential(1));
document.write("<br/>"+numexp.toExponential(2));
document.write("<br/>"+numexp.toExponential(3));
document.write("<br/>"+numexp.toExponential(4));

// tofixed() returns a string 

let numfixed=3.14;
document.write("<br/>"+numfixed.toFixed());
document.write("<br/>"+numfixed.toFixed(2));
document.write("<br/>"+numfixed.toFixed(3));
document.write("<br/>"+numfixed.toFixed(4));

// toprecison() method to return a string with number

let numpre=3.14;
document.write("<br/>"+numpre.toPrecision());
document.write("<br/>"+numpre.toPrecision(2));
document.write("<br/>"+numpre.toPrecision(4));
document.write("<br/>"+numpre.toPrecision(6));


// Number parseInt() parsefloat()

// Max number possible

document.write("<br/>"+Number.MAX_VALUE);

// min Number possible

document.write("<br/>"+Number.MIN_VALUE);


// positive value

document.write("<br/>"+Number.POSITIVE_INFINITY);

// Negative Infinity

document.write("<br/>"+Number.NEGATIVE_INFINITY);

// parseInt

document.write("<br/>"+parseInt("10"));
document.write("<br/>"+parseInt("10.33"));
document.write("<br/>"+parseInt("10"));
document.write("<br/>"+parseInt("10.33"));
document.write("<br/>"+parseInt("year is:10"));

//parsefloat

document.write("<br/>"+parseFloat("10"));
document.write("<br/>"+parseFloat("10.33"));
document.write("<br/>"+parseFloat("10"));
document.write("<br/>"+parseFloat("10 20 30"));
document.write("<br/>"+parseFloat("years 10"));

// date year month day hours minutes seconds

document.write("<br/>"+new Date()); 
document.write("<br/>"+new Date("2003-02-17")); 
document.write("<br/>"+new Date(2023,06,28,10,33,30,0)); 
document.write("<br/>"+new Date("october 13,2023,")); 

var d= new Date();
document.write("<br/>"+d.toString());
document.write("<br/>"+d.toDateString());
document.write("<br/>"+d.toUTCString());
document.write("<br/>"+d.toISOString());


// get time in milliseconds
document.write("<br/>"+d.getTime());
document.write("<br/>"+d.getDate());
document.write("<br/>"+d.getDay());
document.write("<br/>"+d.getFullYear());
document.write("<br/>"+d.getMonth());
document.write("<br/>"+d.getHours());

