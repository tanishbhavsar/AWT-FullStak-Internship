function demoOnClick(){
    alert("tohaare maai ka chode");
}

function demoOnDblClick(){
    alert("Jaldi waha se hato");
}

function demoOnFocus(){
    document.getElementById("txtFocus").style.backgroundColor="blue";
}

function demoOnBlur(){
    document.getElementById("txtBlur").style.backgroundColor="yellow";

}

function demoOnKeypress(){
    alert("keypress Done");
}
function demoOnKeyUp(){
    alert("keyup Done");
}
