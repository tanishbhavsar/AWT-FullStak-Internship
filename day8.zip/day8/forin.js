const Human= {Firstname:"Tanish",LastName:"Bhavsar",age:"20"};
for (let H in Human) {
    document.write("<br/>"+H);
}
document.write("<hr/>");
for (let H in Human) {
    document.write("<br/>"+Human[H]);
}
