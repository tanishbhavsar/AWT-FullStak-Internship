let n1=20,n2=30;

var sum=n1+n2,mul=n1*n2,sub=n1-n2,div=n1/n2,mod=n1%n2;
var Exponentiation=5**2;

document.write("<br/>Sum:",sum+
"<br/>Mul:",mul+
"<br/>Sub:",sub+
"<br/>Div:",div+
"<br/>Modulo:",mod+
"<br/>Post Inc:",n1++ +
"<br/>Post Dec:",n1-- +
"<br/>Pre Inc:",++n1+
"<br/>Pre Dec:",--n1+
"<br/>Exp:",Exponentiation);

