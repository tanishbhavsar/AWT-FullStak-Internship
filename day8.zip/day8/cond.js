
var n1=10,n2="10";

//== equal to value only.
if(n1==n2)
{
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

//=== equal to value & type.
if(n1===n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}