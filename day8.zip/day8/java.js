var a=10;
document.write("value of c:",a);
console.log("value of a",a)

var a=5,b=10;
{
    document.write("<br>",a+b);
}

let c=20;
{
    document.write("<br>",c);
}

const d=9;
document.write("<br>",d);

let name=prompt("what is your name");
document.write(name);



